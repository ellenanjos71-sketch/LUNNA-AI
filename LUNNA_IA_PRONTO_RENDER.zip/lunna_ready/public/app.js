const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);

function showSection(id){
  $$('.section').forEach(x=>x.classList.toggle('active-section',x.id===id));
  $$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.section===id));
  $('.sidebar')?.classList.remove('open');
}
$$('.nav').forEach(b=>b.addEventListener('click',()=>showSection(b.dataset.section)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>showSection(b.dataset.go)));
$('#menu')?.addEventListener('click',()=>$('.sidebar').classList.toggle('open'));

$('#generatePrompt')?.addEventListener('click',()=>{
 const idea=$('#promptInput').value.trim();
 if(!idea)return $('#promptOutput').value='Descreva primeiro o site que você deseja criar.';
 $('#promptOutput').value=`Crie um site profissional, moderno e responsivo para: ${idea}.\n\nInclua identidade visual coerente, navegação clara, hero de impacto, serviços/produtos, benefícios, prova social, galeria/imagens, contato e chamada para ação. Priorize experiência no celular, acessibilidade, SEO básico, carregamento rápido e aparência premium.`;
});
$('#copyPrompt')?.addEventListener('click',()=>copyText($('#promptOutput').value,$('#copyPrompt'),'Copiado!'));

function copyText(text,button,done='Copiado!'){
 if(!text)return;
 navigator.clipboard?.writeText(text).then(()=>{if(button){button.textContent=done;setTimeout(()=>button.textContent='Copiar',1400)}}).catch(()=>alert('Não foi possível copiar automaticamente.'));
}

$('#searchClients')?.addEventListener('click',async()=>{
 const status=$('#searchStatus'), results=$('#results');
 const payload={country:$('#country').value,state:$('#state').value,city:$('#city').value,segment:$('#segment').value,includeContacts:$('#includeContacts').checked};
 status.textContent='Buscando empresas...'; results.innerHTML='';
 try{
   const r=await fetch('/api/prospecting',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
   const data=await r.json(); if(!r.ok)throw new Error(data.error||'Falha');
   (data.results||[]).forEach(x=>results.insertAdjacentHTML('beforeend',resultCard(x,payload)));
   status.textContent=`${data.results?.length||0} resultado(s).`;
 }catch(e){
   status.textContent='Modo demonstração — configure o AI Vibe para resultados reais.';
   results.innerHTML='<div class="result"><b>Modo demonstração</b><small>A conexão com o provedor de prospecção ainda não está configurada.</small></div>';
 }
});
function resultCard(x,p){
 const safe=v=>String(v??'').replace(/[<>&"']/g,m=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&#39;'}[m]));
 return `<div class="result"><b>${safe(x.name||'Empresa')}</b><small>${safe(x.city||p.city||'')} ${safe(x.state||p.state||'')}</small><br><small>${safe(x.phone||x.email||x.website||'Contato não disponível')}</small></div>`;
}

const templates={
 negocio:{label:'Negócio local',eyebrow:'SEU NEGÓCIO DIGITAL',title:'Uma marca que merece ser encontrada.',text:'Apresente seus serviços, conquiste confiança e transforme visitantes em clientes.',sections:['Sobre a marca','Serviços','Depoimentos','Contato'],button:'Falar no WhatsApp',image:'https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=85'},
 clinica:{label:'Clínica / estética',eyebrow:'CUIDADO QUE TRANSFORMA',title:'Cuidado, confiança e uma experiência especial.',text:'Mostre seus serviços com clareza e facilite o contato para agendamentos.',sections:['Especialidades','Equipe','Depoimentos','Agendamento'],button:'Agendar atendimento',image:'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=85'},
 restaurante:{label:'Restaurante',eyebrow:'SABOR & EXPERIÊNCIA',title:'Seu próximo prato favorito começa aqui.',text:'Apresente seu cardápio, ambiente e diferenciais para atrair novos clientes.',sections:['Cardápio','Sobre','Galeria','Reservas'],button:'Ver cardápio',image:'https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=1200&q=85'},
 profissional:{label:'Profissional / serviços',eyebrow:'SOLUÇÕES PARA VOCÊ',title:'Experiência que vira resultado.',text:'Uma apresentação profissional para destacar seu trabalho e facilitar novos contatos.',sections:['Serviços','Experiência','Resultados','Contato'],button:'Entrar em contato',image:'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=85'}
};

function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function detectTemplate(text){const t=text.toLowerCase();if(/restaurante|lanchonete|pizzaria|comida|bar/.test(t))return 'restaurante';if(/clínica|clinica|estética|estetica|dentista|odont/.test(t))return 'clinica';if(/professor|advog|fotóg|fotog|designer|contador|consultor|freela/.test(t))return 'profissional';return 'negocio';}
function buildSite(description,style='lilac'){
 const type=detectTemplate(description); const base=templates[type];
 const name=(description.match(/(?:para|da|do)\s+(.+?)(?:\s+com|,|$)/i)?.[1]||base.label).trim().slice(0,55);
 const palette={lilac:['#8b6cff','#151321','#f7f5ff'],blue:['#2f7cff','#0e1624','#f5f9ff'],green:['#20a46b','#0d1b16','#f3fff9'],rose:['#e85d8d','#211017','#fff6fa']}[style]||['#8b6cff','#151321','#f7f5ff'];
 const [accent,dark,light]=palette;
 const sections=base.sections.map((s,i)=>`<section id="s${i}"><div class="wrap"><div class="kicker">0${i+1}</div><h2>${esc(s)}</h2><p>${i===0?`Conheça ${esc(name)} e descubra uma proposta pensada para oferecer uma experiência clara, moderna e confiável.`:i===1?'Soluções apresentadas de forma simples, com informações importantes e uma chamada para ação em cada etapa.':i===2?'Veja o que clientes e visitantes podem encontrar: qualidade, atenção aos detalhes e uma experiência profissional.':'Fale com nossa equipe para tirar dúvidas, solicitar informações ou começar seu próximo projeto.'}</p>${i===1?'<div class="cards"><article><h3>Atendimento</h3><p>Experiência pensada para você.</p></article><article><h3>Qualidade</h3><p>Detalhes que valorizam sua marca.</p></article><article><h3>Praticidade</h3><p>Contato rápido e direto.</p></article></div>':''}</div></section>`).join('');
 const html=`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="${esc(description)}"><title>${esc(name)} — ${esc(base.label)}</title><style>:root{--a:${accent};--d:${dark};--l:${light}}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:#222;background:var(--l);line-height:1.6}.wrap{width:min(1120px,92%);margin:auto}header{position:sticky;top:0;z-index:5;background:#ffffffee;backdrop-filter:blur(12px);border-bottom:1px solid #ddd;padding:14px 0}.bar{display:flex;align-items:center;justify-content:space-between;gap:20px}.logo{font-weight:900;font-size:20px}.logo span{color:var(--a)}nav{display:flex;gap:18px;flex-wrap:wrap}nav a{color:#333;text-decoration:none;font-weight:700;font-size:14px}.hero{background:linear-gradient(135deg,var(--d),#25243a);color:#fff;padding:90px 0}.hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:45px;align-items:center}.kicker{color:var(--a);font-weight:900;letter-spacing:2px;font-size:12px}.hero h1{font-size:clamp(38px,6vw,72px);line-height:1.02;margin:14px 0}.hero p{color:#ddd;max-width:650px;font-size:18px}.cta{display:inline-block;background:var(--a);color:#fff;text-decoration:none;padding:14px 20px;border-radius:12px;font-weight:900;margin-top:12px}.hero img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:24px;box-shadow:0 25px 70px #0008}section{padding:78px 0}section:nth-of-type(even){background:#fff}h2{font-size:42px;line-height:1.1;margin:8px 0 18px}section p{max-width:760px;color:#62616b;font-size:17px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:30px}.cards article{padding:24px;border:1px solid #ddd;border-radius:18px;background:#fff}.cards h3{margin-top:0}footer{background:var(--d);color:#ddd;padding:30px 0} @media(max-width:760px){.hero-grid{grid-template-columns:1fr}.hero{padding:60px 0}.cards{grid-template-columns:1fr}nav{display:none}h2{font-size:34px}}</style></head><body><header><div class="wrap bar"><div class="logo">${esc(name)} <span>✦</span></div><nav>${base.sections.map((s,i)=>`<a href="#s${i}">${esc(s)}</a>`).join('')}</nav></div></header><main><section class="hero"><div class="wrap hero-grid"><div><div class="kicker">${base.eyebrow}</div><h1>${esc(description.split(/,| com | para /i)[0].trim()||base.title)}</h1><p>${esc(base.text)} ${esc(description)}</p><a class="cta" href="#s${base.sections.length-1}">${base.button} →</a></div><img src="${base.image}" alt="Imagem ilustrativa do negócio"></div></section>${sections}</main><footer><div class="wrap"><strong>${esc(name)}</strong><p>Site criado com a LUNNA IA.</p></div></footer></body></html>`;
 return {html,type,name};
}

$('#createSite')?.addEventListener('click',()=>{
 const description=$('#siteInput').value.trim(); if(!description)return alert('Descreva o negócio para criar o site.');
 const result=buildSite(description,$('#siteStyle')?.value||'lilac');
 $('#sitePreviewFrame').srcdoc=result.html; $('#codeOutput').value=result.html; $('#generatedSite').classList.add('visible');
 $('#siteType').textContent=`Modelo: ${templates[result.type].label}`;
 window.currentSite=result; window.scrollTo({top:document.querySelector('#generatedSite').offsetTop-20,behavior:'smooth'});
});
$('#copyCode')?.addEventListener('click',()=>copyText($('#codeOutput').value,$('#copyCode'),'Código copiado!'));
$('#downloadSite')?.addEventListener('click',()=>{if(!window.currentSite)return;const blob=new Blob([window.currentSite.html],{type:'text/html;charset=utf-8'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='site-lunna-ia.html';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)});
$('#saveProject')?.addEventListener('click',()=>{
 const text=$('#siteInput').value.trim(); if(!text)return alert('Descreva o site antes de salvar.');
 const arr=JSON.parse(localStorage.getItem('lunnaProjects')||'[]'); arr.unshift({text,date:new Date().toLocaleString('pt-BR'),html:window.currentSite?.html||''}); localStorage.setItem('lunnaProjects',JSON.stringify(arr.slice(0,20))); renderProjects(); alert('Projeto salvo!');
});
function renderProjects(){const box=$('#projectList');if(!box)return;const arr=JSON.parse(localStorage.getItem('lunnaProjects')||'[]');box.innerHTML=arr.length?arr.map((p,i)=>`<div class="project"><b>${esc(p.text)}</b><small style="display:block;color:#999;margin:6px 0">${esc(p.date)}</small>${p.html?`<button class="secondary open-project" data-index="${i}">Abrir projeto</button>`:''}</div>`).join(''):'<div class="project">Nenhum projeto salvo neste dispositivo.</div>'; $$('.open-project').forEach(b=>b.addEventListener('click',()=>{const p=arr[+b.dataset.index];showSection('creator');$('#siteInput').value=p.text;if(p.html){window.currentSite={html:p.html};$('#sitePreviewFrame').srcdoc=p.html;$('#codeOutput').value=p.html;$('#generatedSite').classList.add('visible')}}));}
renderProjects();

// Dashboard shortcuts
$('#homeGeneratePrompt')?.addEventListener('click',()=>{
  const idea=$('#homePromptInput')?.value.trim();
  const out=$('#homePromptOutput');
  if(!out)return;
  if(!idea){out.textContent='Descreva primeiro o site que você deseja criar.';return;}
  out.textContent=`Crie um site profissional, moderno e responsivo para: ${idea}. Inclua hero, navegação, serviços, benefícios, prova social, imagens, contato, CTA, SEO básico e experiência mobile.`;
});
$('#homeCopyPrompt')?.addEventListener('click',()=>{
  const text=$('#homePromptOutput')?.textContent||'';
  copyText(text,$('#homeCopyPrompt'),'Copiado!');
});
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}
