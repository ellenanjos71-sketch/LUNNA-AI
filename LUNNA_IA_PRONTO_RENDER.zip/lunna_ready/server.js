
const express=require('express');
const path=require('path');
const app=express();
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));

app.post('/api/prospecting', async (req,res)=>{
  const {country,state,city,segment,includeContacts}=req.body||{};
  const url=process.env.VIBE_API_URL;
  const key=process.env.VIBE_API_KEY;
  if(!url || !key){
    return res.json({results:[
      {name:'Modo demonstração — configure o AI Vibe',city:city||'',state:state||'',phone:'',email:''}
    ]});
  }
  try{
    const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},
      body:JSON.stringify({country,state,city,segment,includeContacts})});
    const data=await response.json();
    if(!response.ok)return res.status(response.status).json({error:data?.error||'Provedor recusou a solicitação'});
    res.json(data);
  }catch(e){res.status(502).json({error:'Não foi possível consultar o provedor.'});}
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`LUNNA IA rodando na porta ${port}`));
