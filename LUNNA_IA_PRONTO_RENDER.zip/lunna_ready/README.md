# LUNNA IA

Plataforma responsiva de marketing inteligente para criação de prompts, prospecção de clientes e criação de sites.

## Publicar no Render

1. Extraia este ZIP.
2. Envie **todos os arquivos e pastas da raiz** para um repositório GitHub.
3. No Render, crie um **Web Service** conectado ao repositório.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. O Render fornece a variável `PORT` automaticamente.
7. Para ativar a prospecção real pelo AI Vibe, adicione `VIBE_API_URL` e `VIBE_API_KEY` em Environment Variables. Nunca coloque a chave no navegador.

Sem essas credenciais, a prospecção permanece em modo demonstração; o restante da interface funciona no navegador.

## Rodar localmente

```bash
npm install
npm start
```

Abra `http://localhost:3000`.
